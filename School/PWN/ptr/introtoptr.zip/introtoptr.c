#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

void apanih(void) {
  system("/bin/sh");
}

int main(void) {
  setbuf(stdin, NULL);
  setbuf(stdout, NULL);
  setbuf(stdout, NULL);
  srand(time(NULL));
  char buffer[72];
  puts("yoo mamen");
  while (1) {
    fgets(buffer, 128, stdin);
    char *s = strstr(buffer, "aku");
    if (s) {
      printf("yo %s, ini introduction to pointer\n", s + 8);
    } else if (strcmp(buffer, "bang, minta flag dong") == 0) {
      puts("hmmm, kasi ga yaa...");
      sleep(5);
      puts("ga mau mwehehe");
    } else if (strcmp(buffer, "nyerah") == 0) {
      puts("wuadaw, gampang banget nyerah ni orang");
      break;
    } else {
      puts("ngasal ae lu");
    }
  }
}
