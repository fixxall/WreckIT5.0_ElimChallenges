#!/bin/bash

socat tcp-l:9243,reuseaddr,fork exec:./introtoptr,stderr
